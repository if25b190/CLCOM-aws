const sum = (a: number, b: number): number => {
  const calculatedSum = a + b;

  return calculatedSum;
};

export default sum;